package week5;

public class WildPokemon {
    String pokemonName;
    int maxHP;
    int HP;
    int attackPower;

    WildPokemon (String pokemonName, int maxHP, int attackPower) {
        this.pokemonName = pokemonName;
        this.maxHP = maxHP;
        this.HP = maxHP;
        this.attackPower = attackPower;
    }
}
