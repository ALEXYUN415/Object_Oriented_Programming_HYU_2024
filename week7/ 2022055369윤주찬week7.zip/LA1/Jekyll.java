package week7.LA1;

public interface Jekyll {
    void beKind();
}
