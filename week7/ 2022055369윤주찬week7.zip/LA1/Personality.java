package week7.LA1;

abstract class Personality {
    abstract void displayBehaviour();
    abstract void transform();
}