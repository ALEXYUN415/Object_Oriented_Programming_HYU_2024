
package week2time2;
import java.util.Scanner;
public class LA2 {
    public static void main(String[] args){

        int sum = 0;
        Scanner input = new Scanner(System.in);
        System.out.println("input : ");

        int num = input.nextInt();
        for (int i = 0; i <= num; i++) {
            sum += i;
        }
        System.out.print(sum);

    }
}
