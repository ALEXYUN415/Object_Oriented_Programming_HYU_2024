package week2time2;

import java.util.Scanner;

public class LA1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("숫자를 입력하시오 : ");
        int value1 = input.nextInt();
        System.out.println("두번째 숫자를 입력하시오 : ");
        int value2 = input.nextInt();


        if (value1 > value2) {
            int ex = value1;
            value1 = value2;
            value2 = ex;
        }

        if (value2 - value1 <= 2) {
            if (value1 == value2) {
                System.out.println("No even numbers found.");
            } else if (value1 % 2 == 1 & value2 % 2 == 1) {
                System.out.print(value1 + 1);
            } else if (value1 % 2 == 0 & value2 % 2 == 0) {
                System.out.print("No even numbers found.");
            } else {
                System.out.print("No even numbers found.");
            }
        } // 두 수의 차이가 2보다 작을떄 and 두 수가 짝수일때
        else {
            for (int i = value1 + 1; i < value2; i++) { /*반복문*/
                if (i % 2 == 0) {
                    System.out.print(i);
                    if (i + 2 < value2) {
                        System.out.print(",");
                    }
                }

            }
        }
    }
}