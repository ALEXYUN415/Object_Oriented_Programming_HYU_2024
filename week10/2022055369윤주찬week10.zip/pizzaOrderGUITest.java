package week10;

public class pizzaOrderGUITest {
    public static void main(String[] args) {
        new pizzaOrderGUI();
    }
}
